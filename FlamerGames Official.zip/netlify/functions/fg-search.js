exports.handler = async function(event) {
  const query = (event.queryStringParameters && event.queryStringParameters.q || '').trim().slice(0, 180);
  if (!query) return reply(400, { error: 'Missing search query', results: [] });
  try {
    const endpoint = 'https://html.duckduckgo.com/html/?q=' + encodeURIComponent(query);
    const upstream = await fetch(endpoint, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; FlamerGamesSearch/1.0)', 'Accept': 'text/html' } });
    if (!upstream.ok) return reply(502, { error: 'Search provider unavailable', results: [] });
    const html = await upstream.text();
    const results = [];
    const anchors = [...html.matchAll(/<a\b(?=[^>]*class="[^"]*result__a[^"]*")(?=[^>]*href="([^"]+)")[^>]*>([\s\S]*?)<\/a>/gi)];
    for (const match of anchors) {
      if (results.length >= 10) break;
      const href = match[0].match(/href="([^"]+)"/i);
      if (!href) continue;
      let url = decode(href[1]);
      const redirect = url.match(/[?&]uddg=([^&]+)/);
      if (redirect) { try { url = decodeURIComponent(redirect[1]); } catch (_) {} }
      if (!/^https?:\/\//i.test(url)) continue;
      const after = html.slice(match.index + match[0].length, match.index + match[0].length + 1800);
      const snippetMatch = after.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/(?:a|td|div)>/i);
      let domain = '';
      try { domain = new URL(url).hostname; } catch (_) {}
      results.push({ title: clean(match[2]) || domain, url, domain, snippet: snippetMatch ? clean(snippetMatch[1]) : '' });
    }
    return reply(200, { query, results });
  } catch (_) {
    return reply(502, { error: 'Could not reach search provider', results: [] });
  }
};
function clean(value) {
  return decode(String(value).replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim().slice(0, 500);
}
function decode(value) {
  return String(value).replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)));
}
function reply(statusCode, body) {
  return { statusCode, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=60', 'X-Content-Type-Options': 'nosniff' }, body: JSON.stringify(body) };
};
