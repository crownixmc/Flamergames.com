FlamerGames — Game Loading Improvement (Netlify)

Deploy the entire extracted folder to Netlify, keeping netlify.toml and netlify/functions/fg-search.js.

Improvements:
- External games now show a clear loading overlay while starting.
- If a game takes longer than 18 seconds, the player shows a retry button and explains that the game may block embedding.
- Added a reload control without leaving FlamerGames.
- Uses eager loading and the game's direct HTTPS URL.
- Eaglercraft version launches use the same loading and retry UI.

Important:
Some external hosts block iframe embedding with their own security headers, or may be offline. A website cannot override those restrictions. The Open in new tab fallback remains available.

For a Git-connected Netlify site, replace index.html and FlamerGames.html and redeploy.

Fix (player):
- Reload game button was unclickable (overlay had pointer-events:none); now works.
- Retry handler no longer stacks up between games (could reload the wrong game's URL).
- Loading overlay now hides correctly after a retry (about:blank load ignored; load listener no longer one-shot).
- Closing the player clears the pending timer/handler. Removed duplicate iframe allow attribute.

Fix (games not loading):
- The Chat/Friends pages were replaced with shutdown notices, but the main script still bound handlers to chat elements that no longer exist. That threw an error during startup and stopped the rest of the script, so Play buttons did nothing. Chat bindings are now skipped when the elements are missing.
- renderAchievements() was called but never defined, which broke the extras startup script; it is now defined.
- Guarded renderChat() and the emoji-picker click handler against the missing chat page.

Fix (exit button):
- Added a ✕ button at the top right of the game player (also closes with Esc).
- The site header was covering the player's top bar, so Close/Open-in-new-tab were unclickable. The player now sits above the header, and the floating Game Requests button hides while a game is open.

Change: the Game Requests button now sits at the bottom-left of the screen.

Fixes (audit pass):
- Search box: was 220px tall (flex-basis applied to height); now 42px tall, max 420px wide.
- Logo smoke: restored as real animated steam above the header logo (the old steam CSS was in a dead block and a later rule overrode it).
- Browser tab icon: now the FlamerGames logo (64px favicon + 180px apple-touch-icon). The old icon links were inside the iframe-protection script text and never reached the page; the competing SVG icon was removed.
- Home: tagline no longer overlaps the paragraph; mirrored "YOUR NEXT FAVORITE" label fixed; game thumbnails keep 16:9 instead of tall boxes with blank bands.
- Announcements: pill/author/date spacing. Chat/Friends shutdown pages: stray "PLAYER AREA" label removed. Stray orange sliver beside the logo removed.
NOTE: ~93KB of older CSS (header wordmark tweaks, etc.) sits inside the iframe-protection <script> text and is currently NOT applied. Turning it on changes the header look a lot, so it was left alone.
